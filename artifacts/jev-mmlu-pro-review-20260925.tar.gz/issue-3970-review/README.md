# Issue #3970 — supplementary MMLU-Pro review package

## Takeaway and questions for agreement

This is a **supplementary exploratory domain-classification experiment**, not completion of the agreed six-case Jev/Kai/Vela pilot, not a replacement of Kai by Laya, and not evidence of end-to-end Router improvement. Laya is an additional exploratory local arm. No adopt/defer/reject decision is claimed.

The original Jev run recorded 120 probability-sum validation errors and 2 timeouts. **The original runner discarded failing probability vectors and did not save raw responses or sums.** These errors are runner-reported observations; the original vectors cannot be independently inspected from this package. A new capture runner is provided, but has not been executed. A new response cannot recover or prove what the original response contained.

Questions to settle with collaborators:

1. Keep this run supplementary while freezing the original shared pilot?
2. Agree on identical Jev/Kai label descriptions and order; this run used label names only, without descriptions.
3. Review the original validation implementation and agree on a diagnostic rerun that retains response data before validation.
4. Agree on abstention, failure policy, latency boundaries, metrics, and artifact hosting before a formal comparison.

## Contents

- `tools/eval/category-comparison/`: byte-for-byte copies of the original runners, mapping and baseline YAML; the separately named `run_jev_capture.py` is new diagnostic instrumentation.
- `tools/eval/category-comparison/results/mmlu-pro/`: all 12,032 input rows and all three complete original output files; original summary retained for provenance.
- `experiment-config.json`: question wording, candidate order, concurrency and experiment scope.
- `evidence/jev-failures-original.jsonl`: all 122 original failure records.
- `evidence/jev-failed-inputs.jsonl`: corresponding public inputs, suitable for a diagnostic rerun.
- `evidence/jev-failure-review.jsonl`: joined inputs and failures, explicitly marking missing raw response/sum evidence.
- `evidence/offline-metrics.json`: metrics recomputed from stored records by `verify.py`.
- `environment-observed.json`: installed dependency versions inspected during package preparation, **not a contemporaneous run environment lock**.
- `SHA256SUMS`: content digests, checked by `verify.py`.

Original discussion: https://github.com/vllm-project/semantic-router/issues/3970#issuecomment-5817472511
Dataset: https://huggingface.co/datasets/TIGER-Lab/MMLU-Pro — test split, English, question text only. The fixture is pinned by SHA256; upstream dataset revision and original extraction script were not retained. Gold labels are present in the fixture but are not sent by the runners to models.

## Offline review — no model downloads or API calls

Run from the extracted package root:

```bash
python3 verify.py
```

It verifies file hashes, unique and identical case ID sets, expected labels, saved valid probability vectors, correctness, coverage and recorded latency percentiles. It cannot validate missing original failure responses.

| Arm | Correct / total | Valid rows | Correct / all | Accuracy on valid |
|---|---:|---:|---:|---:|
| Vela | 8,534 / 12,032 | 12,032 | 70.93% | 70.93% |
| Laya | 6,099 / 12,032 | 12,032 | 50.69% | 50.69% |
| Jev | 9,143 / 12,032 | 11,910 | 75.99% | 76.77% |

## Reproduction setup and commands

Python 3.13; local Laya requires compatible Apple silicon/MLX. See `requirements-observed.txt` for observed versions. Recreating this environment and rerunning models was not tested during packaging. Model versions are pinned by the original runner defaults/config. Paid Jev commands are provided for later execution; they were not executed to prepare this package.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-observed.txt
.venv/bin/python tools/eval/category-comparison/run_baseline.py --input tools/eval/category-comparison/results/mmlu-pro/mmlu-pro-test.jsonl --output /tmp/baseline-new.jsonl --device cpu --warmup-runs 1
.venv/bin/python tools/eval/category-comparison/run_laya.py --input tools/eval/category-comparison/results/mmlu-pro/mmlu-pro-test.jsonl --output /tmp/laya-new.jsonl --warmup-runs 1
# Set TYPESAFE_API_KEY securely in your local environment; no key is included.
.venv/bin/python tools/eval/category-comparison/run_jev_parallel.py --input tools/eval/category-comparison/results/mmlu-pro/mmlu-pro-test.jsonl --output /tmp/jev-new.jsonl --concurrency 16
# Diagnostic rerun, separately labeled, preserving SDK response before validation:
.venv/bin/python tools/eval/category-comparison/run_jev_capture.py --input evidence/jev-failed-inputs.jsonl --output /tmp/jev-diagnostic-new.jsonl --concurrency 16
```

`run_jev_capture.py` saves SDK-parsed response data, returned probability keys/values, probability sum and absolute deviation before validation; it also retains timing for failed attempts. It does not capture raw HTTP bytes. Retries remain disabled. Original outputs must not be replaced by rerun results.

## Limitations that affect interpretation

- The original Jev runner selects the configured labels before comparing label sets. Its equality check cannot detect extra returned labels. New capture instrumentation checks the full returned set. No renormalization occurs, but complete original response preservation was missing.
- The Python validation is not execution of the Router's shared connector or Go validator. No production adapter was tested.
- Vela uses the highest-probability class. The runner does **not** apply the Router threshold 0.5 / fallback `other` policy, even though earlier pilot discussion described that production configuration. `baseline.yaml` retains a pilot dataset-version tag; the actual dataset is the supplied MMLU-Pro file.
- Original Jev failure records omit latency and usage. Jev percentiles describe valid calls only; they are not all-request latency including timeouts/fallback. Semaphore queue wait is excluded.
- Vela timing excludes tokenization and includes model inference; Laya times `predict`; Jev times the SDK call including network. CPU / Apple silicon / hosted API measurements are not matched-hardware model-speed comparisons. Jev model-only timing is unavailable. Test network/location and detailed run-time hardware provenance were not captured.
- `verify.py` uses linearly interpolated percentiles. P95 is 60.99 / 17.15 / 459.55 ms for Vela/Laya/Jev; the original posted values were 60.95 / 17.14 / 459.44 ms. The original percentile implementation was not retained; do not silently overwrite historical figures.
- No held-out protocol agreement, Kai arm, multilingual/OOD/adversarial suite, abstention sweep, paired uncertainty estimates or downstream task-success evaluation is supplied here. Calibration and per-classal susy vectors, c usaeexplicitly mgreed salid /ll /ommaon-alid propulaions.
3-Applroxmatesy m$0.23was neported oy the oxperiment swnsr prom the eiliing pdsh
bordw No pinvoce ,scrieenrs,tor dndependently ierifieble filiing pxperteis included.;usage.on vailed aalls oas not retained;
- The Package rs propare dlocal y. To prblic iratnch,artifact hupoadsor dnsue #eplayhas neen emad.
